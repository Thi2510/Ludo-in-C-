﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;



namespace ConsoleApp1
{
    class Program
    {
        static int RolarDado()
        {
            Random random = new Random();
            int resultado = random.Next(1, 7);
            return resultado;
        }
 
        public static void CapturaVermelho(int[] peoesvermelhos,int numero, int[] peoesverdes, string[] nomepeaovermelho, string[]nomepeaoverde)
        {
            for (int i = 0; i < 4; i++) //CAPTURA
            {
                if (peoesvermelhos[numero] == peoesverdes[i])
                {

                    if (peoesverdes[i] == 1 || peoesverdes[i] == 9 || peoesverdes[i] == 14 || peoesverdes[i] == 22 || peoesverdes[i] == 27 || peoesverdes[i] == 35 || peoesverdes[i] == 40 || peoesverdes[i] == 48)
                    {
                        Console.WriteLine("O peão" + nomepeaovermelho[numero] + " divide a mesma casa que o peão verde " + nomepeaoverde[i]);
                    }
                    else
                    {
                        peoesverdes[i] = 0;
                    }

                }
            }
        }//FUNÇÃO DE CAPTURA DO JOGADOR VERMELHO
        public static void CapturaVerde(int[] peoesvermelhos, int numero, int[] peoesverdes, string[] nomepeaovermelho, string[] nomepeaoverde)
        {
            for (int i = 0; i < 4; i++) //CAPTURA
            {
                if (peoesverdes[numero] == peoesvermelhos[i])
                {

                    if (peoesvermelhos[i] == 1 || peoesvermelhos[i] == 9 || peoesvermelhos[i] == 14 || peoesvermelhos[i] == 22 || peoesvermelhos[i] == 27 || peoesvermelhos[i] == 35 || peoesvermelhos[i] == 40 || peoesvermelhos[i] == 48)
                    {
                        Console.WriteLine("O peão" + nomepeaoverde[numero] + " divide a mesma casa que o peão verde " + nomepeaovermelho[i]);
                    }
                    else
                    {
                        peoesvermelhos[i] = 0;
                    }

                }
            }
        }// FUNÇÃO DE CAPTURA DO JOGADOR VERDE
        public static void UsoDadoVermelho(int[] peoesvermelhos, int numero, int dado)//DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERMELHO(SITUAÇÕES DO JOGO)
        {
            if (peoesvermelhos[numero] + dado > 57)
            {
                Console.WriteLine("O peão " + peoesvermelhos[numero] + "passou do limite e não poderá ser movido ");
            }
            else if (peoesvermelhos[numero] == 0)
            {
                peoesvermelhos[numero] = 1;
            }
            else
            {
                peoesvermelhos[numero] = peoesvermelhos[numero] + dado;
            }
        }
        public static void UsoDadoVerde(int[] peoesverdes, int numero, int dado)//DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERDE(SITUAÇÕES DO JOGO) 
        {
            if (peoesverdes[numero] + dado > 57)
            {
                Console.WriteLine("O peão " + peoesverdes[numero] + "passou do limite e não poderá ser movido ");
            }
            else if (peoesverdes[numero] == 0)
            {
                peoesverdes[numero] = 1;
            }
            else
            {
                peoesverdes[numero] = peoesverdes[numero] + dado;
            }
        }
        static void Jogadas(int[] peoesvermelhos, int[] peoesverdes,bool rodada,int contagemseis) //FUNÇÃO QUE MOSTRA O FUNCIONAMENTO DAS JOGADAS DE CADA JOGADOR
        {
            string[] nomepeaovermelho = { "0", "1", "2", "3" };
            string[] nomepeaoverde = { "0", "1", "2", "3" };
            int contagemInicioJogVermelho=0;
            int contagemInicioJogVerde=0;
            int dado = RolarDado();
            int numero;
            string peoesvermelhosdisp = "";
            

            if (rodada == true)// JOGADAS DENTRO DE UM IF
            {
                Console.WriteLine("É a vez do Jogador VERMELHO");//VEZ DO JOGADOR VERMELHO
                Console.WriteLine("O resultado do dado foi " + dado);
                contagemInicioJogVermelho = 0;

                for(int i = 0;i < 4; i++) 
                {
                    if (peoesvermelhos[i]==57) 
                    {
                        Console.WriteLine("O peão " + peoesvermelhos[i] + " está indisponível"); 
                    }
                    else if (peoesvermelhos[i] != 0) 
                    {
                        peoesvermelhosdisp = peoesvermelhosdisp + " , ";
                        contagemInicioJogVermelho++;
                    }
                   
                }
                
                if(dado != 6 && contagemInicioJogVermelho != 0) 
                {   
                    for (int i = 0; i < 4; i++)
                    {
                        if (peoesvermelhos[i] != 0)
                        {
                            Console.WriteLine("O Peão Vermelho " +nomepeaovermelho[i] + " está disponível");
                        }
                    }
                    Console.WriteLine("Digite o número do peão que deseja mover");
                    numero= int.Parse(Console.ReadLine());
                    Console.WriteLine("O resultado do dado é " + dado);
                    UsoDadoVermelho(peoesvermelhos, numero, dado); //DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERMELHO(SITUAÇÕES DO JOGO)
                    CapturaVermelho(peoesvermelhos, numero, peoesverdes, nomepeaovermelho, nomepeaoverde);////FUNÇÃO DE CAPTURA DO JOGADOR VERMELHO
                }
                else if(contagemInicioJogVermelho == 0 && dado != 6) 
                {
                    Console.WriteLine("Passou a vez");
                    Console.ReadKey();

                }
                else if(contagemInicioJogVermelho == 0 && dado == 6) 
                {
                    contagemseis++;
                    for (int i = 0; i < 4; i++)
                    {
                      Console.WriteLine("O Peão Vermelho " + nomepeaovermelho[i] + " está disponível");
                       
                    }
                    Console.WriteLine("Digite o número do peão que deseja mover");
                    numero = int.Parse(Console.ReadLine());
                    Console.WriteLine("O resultado do dado é " + dado);
                    UsoDadoVermelho(peoesvermelhos, numero, dado); //DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERMELHO(SITUAÇÕES DO JOGO)
                    CapturaVermelho(peoesvermelhos, numero, peoesverdes, nomepeaovermelho, nomepeaoverde);////FUNÇÃO DE CAPTURA DO JOGADOR VERMELHO
                    if (contagemseis == 1) 
                    {
                        Console.WriteLine("Aperte qualquer botão para jogar novamente!");
                        Console.ReadKey();
                        Console.Clear();
                        Jogadas(peoesvermelhos,peoesverdes, rodada, contagemseis);
                    }
                    else if(contagemseis ==2)
                    {
                        Console.WriteLine("Perdeu a vez!");
                    }

                }
                else if(contagemInicioJogVermelho!=0 && dado == 6) 
                {
                    contagemseis++;
                    for (int i = 0; i < 4; i++)
                    {
                      Console.WriteLine("O Peão Vermelho " + nomepeaovermelho[i] + " está disponível");
                        
                    }
                    Console.WriteLine("Digite o número do peão que deseja mover");
                    numero = int.Parse(Console.ReadLine());
                    Console.WriteLine("O resultado do dado é " + dado);
                    UsoDadoVermelho(peoesvermelhos, numero, dado); //DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERMELHO(SITUAÇÕES DO JOGO)
                    CapturaVermelho(peoesvermelhos, numero, peoesverdes, nomepeaovermelho, nomepeaoverde);////FUNÇÃO DE CAPTURA DO JOGADOR VERMELHO
                    if (contagemseis == 1)
                    {
                        Console.WriteLine("Aperte qualquer botão para jogar novamente!");
                        Console.ReadKey();
                        Console.Clear();
                        Jogadas(peoesvermelhos, peoesverdes, rodada, contagemseis);
                    }
                    else if (contagemseis == 2)
                    {
                        Console.WriteLine("Perdeu a vez!");
                        Console.ReadKey();
                    }

                }
                
            }
            else if(rodada==false)
            {
                Console.WriteLine("É a vez do Jogador VERDE");//VEZ DO JOGADOR VERDE
                Console.WriteLine("O resultado do dado foi " + dado);
                contagemInicioJogVerde = 0;
                for (int i = 0; i < 4; i++)
                {
                    if (peoesverdes[i] != 0)
                    {
                        contagemInicioJogVerde++;
                    }
                }

                if (dado != 6 && contagemInicioJogVerde != 0)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        if (peoesverdes[i] != 0)
                        {
                            Console.WriteLine("O Peão Verde " + nomepeaoverde[i] + " está disponível");
                        }
                    }
                    Console.WriteLine("Digite o número do peão que deseja mover");
                    numero = int.Parse(Console.ReadLine());
                    Console.WriteLine("O resultado do dado é " + dado);
                    UsoDadoVerde(peoesverdes, numero, dado);//DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERDE(SITUAÇÕES DO JOGO)
                    CapturaVerde(peoesvermelhos, numero, peoesverdes, nomepeaovermelho, nomepeaoverde);//FUNÇÃO DE CAPTURA DO JOGADOR VERDE
                }
                else if (contagemInicioJogVerde == 0 && dado != 6)
                {
                    Console.WriteLine("Passou a vez");
                    Console.ReadKey();

                }
                else if (contagemInicioJogVerde == 0 && dado == 6)
                {
                    contagemseis++;
                    for (int i = 0; i < 4; i++)
                    {
                        Console.WriteLine("O Peão Verde " + nomepeaoverde[i] + " está disponível");

                    }
                    Console.WriteLine("Digite o número do peão que deseja mover");
                    numero = int.Parse(Console.ReadLine());
                    Console.WriteLine("O resultado do dado é " + dado);
                    UsoDadoVerde(peoesverdes, numero, dado);//DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERDE(SITUAÇÕES DO JOGO)
                    CapturaVerde(peoesvermelhos, numero, peoesverdes, nomepeaovermelho, nomepeaoverde);//FUNÇÃO DE CAPTURA DO JOGADOR VERDE
                    if (contagemseis == 1)
                    {
                        Console.WriteLine("Aperte qualquer botão para jogar novamente!");
                        Console.ReadKey();
                        Console.Clear();
                        Jogadas(peoesvermelhos, peoesverdes, rodada, contagemseis);
                    }
                    else if (contagemseis == 2)
                    {
                        Console.WriteLine("Perdeu a vez!");
                    }

                }
                else if (contagemInicioJogVerde != 0 && dado == 6)
                {
                    contagemseis++;
                    for (int i = 0; i < 4; i++)
                    {
                        Console.WriteLine("O Peão Vermelho " + nomepeaoverde[i] + " está disponível");

                    }
                    Console.WriteLine("Digite o número do peão que deseja mover");
                    numero = int.Parse(Console.ReadLine());
                    Console.WriteLine("O resultado do dado é " + dado);
                    UsoDadoVerde(peoesverdes, numero, dado);//DEFINIR A MOVIMENTAÇÃO DO JOGADOR VERDE(SITUAÇÕES DO JOGO)
                    CapturaVerde(peoesvermelhos, numero, peoesverdes, nomepeaovermelho, nomepeaoverde);//FUNÇÃO DE CAPTURA DO JOGADOR VERDE
                    if (contagemseis == 1)
                    {
                        Console.WriteLine("Aperte qualquer botão para jogar novamente!");
                        Console.ReadKey();
                        Console.Clear();
                        Jogadas(peoesvermelhos, peoesverdes, rodada, contagemseis);
                    }
                    else if (contagemseis == 2)
                    {
                        Console.WriteLine("Perdeu a vez!");
                    }

                }
               
            }
                       
        }
        static void Main(string[] args)

        {   
            string vitoriajogador = "";
            bool rodada=true;
            int[]peoesvermelhos= { 0, 0, 0, 0 };
            int[]peoesverdes = { 0, 0, 0, 0 };
            int contagemseis=0;
            int contagemfim=0;
            bool vitoria=false;
            Console.WriteLine("Bem Vindo ao Ludo");
            while (vitoria == false) 
            {

                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("Posição dos peões vermelhos " + peoesvermelhos[i]);
                }
                Console.WriteLine("##########################################");
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine("Posição dos peões verdes " + peoesverdes[i]);
                }
                Console.ReadKey();
                Console.Clear();
                Jogadas(peoesvermelhos, peoesverdes, rodada, contagemseis);
                for (int i = 0; i < 4; i++) //VERIFICAÇÃO DE VITÓRIA DO JOGADOR VERMELHO(
                {
                    if (peoesvermelhos[i] == 57)
                    {
                        contagemfim++;
                    }
                }
                
                if (contagemfim == 4)
                {
                    vitoria = true;
                    vitoriajogador = "VERMELHO";
                }
                else
                {
                    contagemfim = 0;
                }
                
                for (int i = 0; i < 4; i++)// VERIFICAÇÃO DE VITÓRIA DO JOGADOR VERDE(
                {
                    if (peoesverdes[i] == 57)
                    {
                        contagemfim++;
                    }
                }
                if (contagemfim == 4)
                {
                    vitoria = true;
                    vitoriajogador = "VERDE";
                }
                else
                {
                    contagemfim = 0;
                }
                
                contagemseis=0;
                if (rodada == true) 
                {
                    rodada= false;
                }
                else if (rodada == false) 
                {
                    rodada = true;
                }
            }
           
            Console.WriteLine("Vitória do jogador " + vitoriajogador);
        }

    }
}
